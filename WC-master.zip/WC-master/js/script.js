const searchBtn = document.querySelector('#search-icon');



// Add an event listener to the search button
searchBtn.addEventListener('click', () => {
	// Get the search term from the input field
	var searchTerm = document.querySelector('#search').value;
	searchTerm = searchTerm.toLowerCase();
	// Redirect the user to the appropriate page
	switch(searchTerm) {
		case 'dubai':
			window.location.href = './Dubai.html';
			break;
		case 'page2':
			window.location.href = 'page2.html';
			break;
		case 'page3':
			window.location.href = 'page3.html';
			break;
		// Add more cases for additional pages
		default:
			alert('Page not found');
			break;
	}
});

